/* UnTeamSpeak
 * by [g00n]JaGx (g00ns.net)
 */
using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace UnTeamSpeak
{
    class UnTeamSpeakMain
    {
        static void Main(string[] args)
        {
            TeamSpeak ts = new TeamSpeak("205.209.164.88", 8767);
            ts.login("UnTeamSpeak", "Walmart Distribution Center", 0x0007002100210001, true, true, "jewCipher", "c2vst5ax9064yghy", "Keebler Elf");
           /* for (int i = 0; i < ts.players.Count; i++)
            {
                Console.WriteLine(ts.players[i]);
            }*/
        }
    }
}
